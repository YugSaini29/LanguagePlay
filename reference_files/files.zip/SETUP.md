# 🐱 Meow Guru — Android App (Kotlin + Compose)

Native Android app. Backend wahi hai jo web app use karta hai — **koi API rewrite nahi**.

---

## 📦 Kya-kya andar hai

| Feature | File |
|---|---|
| 🐱 Cat + radiating waves + lip-sync | `ui/CatView.kt` |
| 💬 Chat (bilingual, corrections, tips) | `ui/ChatScreen.kt` |
| 🎤 Mic (STT) — native, hang-proof | `speech/SpeechManager.kt` |
| 🔊 TTS — **male voice preferred** + slow mode | `speech/TtsManager.kt` |
| 🎮 Quiz (+XP, repeat-proof) | `ui/Screens.kt` |
| 🏆 Leaderboard | `ui/Screens.kt` |
| 📅 7-day challenge + streak | `data/Prefs.kt` |
| 🗣 Pronunciation score (Levenshtein) | `ui/MeowVm.kt` |
| 🔴 Google Sign-In (Credential Manager) | `auth/GoogleAuth.kt` |
| 🔔 Local notifications (daily + streak-danger) | `notif/Notifs.kt` |
| 📲 Push notifications (FCM) | `notif/Notifs.kt` → `MeowFcmService` |
| 🌙 Dark mode, ⭐ phrasebook, 🌐 language switch | `ui/Screens.kt` |

---

## 🚀 Setup — 5 steps

### 1. Android Studio me kholo
`File → Open` → is folder ko select karo → Gradle sync hone do.

### 2. Server pe naya endpoint daalo
```bash
sudo cp server/fcm.php /var/www/html/languageplay/api/fcm.php
sudo chown www-data:www-data /var/www/html/languageplay/api/fcm.php
```
(Table `lp_devices` khud ban jayegi — kuch nahi karna.)

### 3. Google Sign-In — Android OAuth client
Google Cloud Console → **Credentials → Create → OAuth client ID → Android**
- Package name: `in.languageplay.meowguru`
- SHA-1: terminal me `./gradlew signingReport` → debug wala SHA-1 copy karo
- Release ke liye baad me apni release keystore ka SHA-1 bhi add karna

⚠️ `BuildConfig.GOOGLE_WEB_CLIENT_ID` me **WEB client id** hi rehne do (jo already dala hai) — ye sahi hai. Android app WEB client id maangta hai, aur `google-auth.php` usi `aud` ko check karta hai. **Backend me koi change nahi.**

### 4. Push notifications (FCM) — optional
1. [Firebase Console](https://console.firebase.google.com) → naya project → Android app add karo (`in.languageplay.meowguru`)
2. `google-services.json` download → `app/` folder me daalo
3. `app/build.gradle.kts` me ye line uncomment karo:
   ```kotlin
   id("com.google.gms.google-services")
   ```
4. Sync + run

**FCM ke bina bhi app chalega** — local notifications (daily reminder, streak alert) WorkManager se chalti hain, unhe Firebase nahi chahiye.

### 5. Run
Phone connect karo → ▶️ Run. Bas.

---

## ⚙️ Config badalna ho toh
`app/build.gradle.kts` → `defaultConfig` me:
```kotlin
buildConfigField("String", "API_BASE", "\"https://languageplay.in/languageplay/api/\"")
buildConfigField("String", "BOT_URL", "\"https://t.me/MeowGuruBot\"")
buildConfigField("boolean", "CONNECT_ENABLED", "false")   // 18+ chat — Play Store ke liye false
```

---

## ⚠️ Play Store — pehle se jaan lo

1. **Meow Connect (18+ chat) app me nahi hai** (`CONNECT_ENABLED = false`). Ye jaan-bujh ke — UGC/18+ chat wale apps ko Play Store review me sakht policy jhelni padti hai (moderation, age verification, content rating). App abhi **pure learning app** hai → approval seedha. Connect web pe chalta rahega. Baad me add kar sakte hain.

2. **Mic har bhasha me nahi chalega** — Android STT sirf Google-supported languages me hai. Jahan nahi hai, wahan clear message aata hai aur user type kar sakta hai.

3. **Naye developer accounts ko 12 testers × 14 din closed testing** karni padti hai production se pehle. Aaj se testers jodna shuru karo.

4. **Data safety form** bharna hoga: audio (mic — device pe process hota hai, store nahi), email/name (Google Sign-In), device id (FCM). Privacy policy URL: `https://languageplay.in/languageplay/privacy.html`

---

## 🔨 Release build
```bash
./gradlew assembleRelease      # APK
./gradlew bundleRelease        # AAB (Play Store ke liye yahi)
```
Signing config `app/build.gradle.kts` me add karni hogi (keystore banane ke baad).

---

Made with ❤️ by Rocket Examica × Tech Eagles · Mahakumbrix Innovation
