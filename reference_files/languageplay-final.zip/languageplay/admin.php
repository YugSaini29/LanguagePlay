<?php
/** 🛡️ Meow Connect Admin — reports, bans, stats
 *  Password: dbconfig.php me ADMIN_PASS (ISE ZAROOR BADLO!)
 */
session_start();
require __DIR__ . '/api/dbconfig.php';

/* is_banned column auto-migrate (purani DB ke liye) */
$col = $mysqli->query("SELECT COUNT(*) c FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='lp_profiles' AND COLUMN_NAME='is_banned'");
if ($col && (int)$col->fetch_assoc()['c'] === 0) {
    $mysqli->query("ALTER TABLE lp_profiles ADD COLUMN is_banned TINYINT DEFAULT 0");
}

/* login/logout */
if (isset($_POST['pw'])) {
    if (hash_equals(ADMIN_PASS, (string)$_POST['pw'])) $_SESSION['meow_admin'] = 1;
    header('Location: admin.php'); exit;
}
if (isset($_GET['logout'])) { unset($_SESSION['meow_admin']); header('Location: admin.php'); exit; }
$in = !empty($_SESSION['meow_admin']);

/* actions */
if ($in && isset($_GET['act'])) {
    $id = (int)($_GET['id'] ?? 0);
    if ($_GET['act'] === 'ban')     $mysqli->query("UPDATE lp_profiles SET is_banned=1 WHERE user_id=$id");
    if ($_GET['act'] === 'unban')   $mysqli->query("UPDATE lp_profiles SET is_banned=0 WHERE user_id=$id");
    if ($_GET['act'] === 'delmsg')  $mysqli->query("UPDATE lp_messages SET flagged=1 WHERE id=$id");
    if ($_GET['act'] === 'dismiss') $mysqli->query("DELETE FROM lp_reports WHERE id=$id");
    header('Location: admin.php'); exit;
}

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🛡️ Meow Admin — Language Play</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box;font-family:"Segoe UI",system-ui,sans-serif}
  body{background:#F2F7FD;color:#243447;padding:18px;max-width:960px;margin:0 auto}
  h1{color:#1E3A6E;font-size:22px;margin-bottom:4px}
  .sub{color:#8B98A8;font-size:12.5px;font-weight:700;margin-bottom:16px}
  .stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-bottom:18px}
  .st{background:#fff;border:1.5px solid #E0EBF7;border-radius:14px;padding:12px;text-align:center}
  .st b{display:block;font-size:22px;color:#1E3A6E}
  .st span{font-size:11.5px;color:#8B98A8;font-weight:700}
  .card{background:#fff;border:1.5px solid #E0EBF7;border-radius:14px;padding:13px;margin-bottom:10px}
  .card .meta{font-size:12px;color:#8B98A8;font-weight:700;margin-bottom:6px}
  .card .msg{background:#F8FBFF;border-radius:10px;padding:8px 10px;font-size:13.5px;margin:6px 0}
  .btn{display:inline-block;text-decoration:none;font-size:12.5px;font-weight:800;border-radius:999px;
       padding:7px 14px;margin:4px 4px 0 0;color:#fff}
  .ban{background:#E85D5D}.ok{background:#3FBF6F}.gray{background:#8B98A8}.blue{background:#4FB3F6}
  input[type=password]{padding:11px 14px;border:2px solid #C9DFF5;border-radius:12px;font-size:15px;width:240px}
  button{padding:11px 20px;border:none;border-radius:12px;background:#F5871F;color:#fff;font-weight:800;
         font-size:15px;cursor:pointer;margin-left:6px}
  .empty{color:#8B98A8;font-weight:700;font-size:14px;padding:20px;text-align:center}
  .banned{color:#E85D5D;font-weight:800}
  .foot{text-align:center;color:#A8B4C4;font-size:11.5px;font-weight:700;margin:24px 0 8px}
</style>
</head>
<body>
<h1>🛡️ Meow Connect Admin</h1>
<div class="sub">Language Play · Reports & Safety Panel</div>

<?php if (!$in): ?>
  <div class="card" style="max-width:400px">
    <form method="post">
      <b style="color:#1E3A6E">🔐 Admin Login</b><br><br>
      <input type="password" name="pw" placeholder="Admin password" autofocus>
      <button>Login</button>
    </form>
  </div>
<?php else: ?>
  <?php
  $S = fn($q) => (int)$mysqli->query($q)->fetch_assoc()['c'];
  $stats = [
    ['Users', $S("SELECT COUNT(*) c FROM lp_users")],
    ['Profiles', $S("SELECT COUNT(*) c FROM lp_profiles")],
    ['Linked TG', $S("SELECT COUNT(*) c FROM lp_links")],
    ['Messages', $S("SELECT COUNT(*) c FROM lp_messages")],
    ['Reminders', $S("SELECT COUNT(*) c FROM lp_reminders")],
    ['Reports', $S("SELECT COUNT(*) c FROM lp_reports")],
    ['Banned', $S("SELECT COUNT(*) c FROM lp_profiles WHERE is_banned=1")],
  ];
  ?>
  <div class="stats">
    <?php foreach ($stats as $s): ?>
      <div class="st"><b><?= $s[1] ?></b><span><?= $s[0] ?></span></div>
    <?php endforeach; ?>
  </div>

  <h2 style="color:#1E3A6E;font-size:17px;margin-bottom:10px">🚨 Reports</h2>
  <?php
  $res = $mysqli->query(
    "SELECT r.id, r.reason, r.created_at, r.message_id,
            r.reporter_id, COALESCE(p1.display_name,'?') rep_name,
            r.reported_id, COALESCE(p2.display_name,'?') bad_name,
            COALESCE(p2.is_banned,0) bad_banned,
            m.original_text, m.translated_text
     FROM lp_reports r
     LEFT JOIN lp_profiles p1 ON p1.user_id=r.reporter_id
     LEFT JOIN lp_profiles p2 ON p2.user_id=r.reported_id
     LEFT JOIN lp_messages m ON m.id=r.message_id
     ORDER BY r.id DESC LIMIT 100");
  if (!$res || !$res->num_rows) echo '<div class="empty">📭 Koi report nahi — sab shanti hai! 🐱</div>';
  while ($r = $res->fetch_assoc()): ?>
    <div class="card">
      <div class="meta">#<?= $r['id'] ?> · <?= h($r['created_at']) ?> ·
        Reporter: <b><?= h($r['rep_name']) ?></b> →
        Reported: <b class="<?= $r['bad_banned'] ? 'banned' : '' ?>"><?= h($r['bad_name']) ?><?= $r['bad_banned'] ? ' (BANNED)' : '' ?></b>
        <?= $r['reason'] ? '· Reason: ' . h($r['reason']) : '' ?></div>
      <?php if ($r['original_text']): ?>
        <div class="msg">💬 <?= h($r['original_text']) ?><br><small>→ <?= h($r['translated_text']) ?></small></div>
      <?php endif; ?>
      <?php if ($r['bad_banned']): ?>
        <a class="btn ok" href="?act=unban&id=<?= (int)$r['reported_id'] ?>" onclick="return confirm('Unban?')">✔ Unban</a>
      <?php else: ?>
        <a class="btn ban" href="?act=ban&id=<?= (int)$r['reported_id'] ?>" onclick="return confirm('Ban user?')">🚫 Ban User</a>
      <?php endif; ?>
      <?php if ($r['message_id']): ?>
        <a class="btn gray" href="?act=delmsg&id=<?= (int)$r['message_id'] ?>">🗑 Hide Message</a>
      <?php endif; ?>
      <a class="btn blue" href="?act=dismiss&id=<?= (int)$r['id'] ?>">✔ Dismiss</a>
    </div>
  <?php endwhile; ?>

  <div style="margin-top:14px"><a class="btn gray" href="?logout=1">Logout</a></div>
<?php endif; ?>

<div class="foot">Made with ❤️ by Rocket Examica × Tech Eagles · Mahakumbrix Innovation</div>
</body>
</html>
