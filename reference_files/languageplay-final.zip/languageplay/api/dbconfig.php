<?php
/** MySQL + bot config — languageplay web side */
define('BOT_USERNAME', 'MeowGuruBot');   // BotFather username (bina @)
define('GOOGLE_CLIENT_ID', '433797561933-k8rtptd6v7f8vg9j2071sdj9l6hcm3go.apps.googleusercontent.com');
define('ADMIN_PASS', 'MeowAdmin@2026');   // admin.php ka password — ISE BADLO!
define('BOT_TOKEN', '8878741105:AAHnr6Z3If-RoqyMXZvy7HpOIWkzHERTUfg'); // Telegram pings ke liye

$mysqli = @new mysqli('localhost', 'admin', 'StrongPassword123!', 'eagle_auth');
if ($mysqli->connect_error) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'DB connection failed']);
    exit;
}
$mysqli->set_charset('utf8mb4');

/* ---- auto-migrations (purani DB safe) ---- */
function _lp_addcol($db, $table, $col, $ddl) {
    $r = $db->query("SELECT COUNT(*) c FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='$table' AND COLUMN_NAME='$col'");
    if ($r && (int)$r->fetch_assoc()['c'] === 0) $db->query("ALTER TABLE $table ADD COLUMN $ddl");
}
_lp_addcol($mysqli, 'lp_profiles', 'is_banned', 'is_banned TINYINT DEFAULT 0');
_lp_addcol($mysqli, 'lp_users', 'google_id', 'google_id VARCHAR(64) NULL UNIQUE');
_lp_addcol($mysqli, 'lp_users', 'email', 'email VARCHAR(120) NULL');
_lp_addcol($mysqli, 'lp_users', 'picture', 'picture VARCHAR(300) NULL');

/** user_key se user lao; nahi hai toh naya banao. Returns ['id','user_key'] */
function ensure_user(mysqli $db, string $user_key): array {
    $user_key = preg_replace('/[^a-f0-9]/', '', $user_key);
    if (strlen($user_key) === 32) {
        $st = $db->prepare("SELECT id, user_key FROM lp_users WHERE user_key=?");
        $st->bind_param('s', $user_key);
        $st->execute();
        if ($u = $st->get_result()->fetch_assoc()) return $u;
    }
    $user_key = bin2hex(random_bytes(16));
    $map = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $secret = '';
    for ($i = 0; $i < 16; $i++) $secret .= $map[random_int(0, 31)];
    $st = $db->prepare("INSERT INTO lp_users (user_key, totp_secret) VALUES (?,?)");
    $st->bind_param('ss', $user_key, $secret);
    $st->execute();
    return ['id' => $db->insert_id, 'user_key' => $user_key];
}

/** Telegram message bhejo (friend pings) — fail silently */
function tg_ping(int $chat_id, string $text): void {
    $ch = curl_init("https://api.telegram.org/bot" . BOT_TOKEN . "/sendMessage");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 5,
        CURLOPT_POSTFIELDS => http_build_query([
            'chat_id' => $chat_id, 'text' => $text, 'parse_mode' => 'HTML']),
    ]);
    curl_exec($ch);
    curl_close($ch);
}
