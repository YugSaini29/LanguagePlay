<?php
/** Meow Connect — friend system (sirf friends hi chat/notify kar sakte hain) */
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo '{"ok":false}'; exit; }
require __DIR__ . '/dbconfig.php';

$b = json_decode(file_get_contents('php://input'), true) ?: [];
$action = (string)($b['action'] ?? '');
$u = ensure_user($mysqli, (string)($b['user_key'] ?? ''));
$uid = (int)$u['id'];

$st = $mysqli->prepare("SELECT display_name, is_adult, is_banned FROM lp_profiles WHERE user_id=?");
$st->bind_param('i', $uid); $st->execute();
$me = $st->get_result()->fetch_assoc();
if (!$me || !$me['is_adult']) { echo json_encode(['ok' => false, 'error' => 'adult_only']); exit; }
if (!empty($me['is_banned'])) { echo json_encode(['ok' => false, 'error' => 'Account blocked']); exit; }
$mysqli->query("UPDATE lp_profiles SET last_seen=NOW() WHERE user_id=$uid");

function is_blocked(mysqli $db, int $a, int $b): bool {
    $st = $db->prepare("SELECT 1 FROM lp_blocks WHERE (user_id=? AND blocked_id=?) OR (user_id=? AND blocked_id=?)");
    $st->bind_param('iiii', $a, $b, $b, $a); $st->execute();
    return (bool)$st->get_result()->fetch_row();
}
function tg_of(mysqli $db, int $uid): ?int {
    $st = $db->prepare("SELECT telegram_chat_id FROM lp_links WHERE user_id=?");
    $st->bind_param('i', $uid); $st->execute();
    $r = $st->get_result()->fetch_assoc();
    return $r ? (int)$r['telegram_chat_id'] : null;
}

if ($action === 'request') {
    $to = (int)($b['to_id'] ?? 0);
    if (!$to || $to === $uid || is_blocked($mysqli, $uid, $to)) { echo '{"ok":false,"error":"invalid"}'; exit; }
    $st = $mysqli->prepare("SELECT is_adult FROM lp_profiles WHERE user_id=?");
    $st->bind_param('i', $to); $st->execute();
    $tp = $st->get_result()->fetch_assoc();
    if (!$tp || !$tp['is_adult']) { echo '{"ok":false,"error":"invalid"}'; exit; }
    /* reverse pending? toh direct accept */
    $st = $mysqli->prepare("SELECT id FROM lp_friends WHERE from_id=? AND to_id=? AND status='pending'");
    $st->bind_param('ii', $to, $uid); $st->execute();
    if ($st->get_result()->fetch_row()) {
        $mysqli->query("UPDATE lp_friends SET status='accepted' WHERE from_id=$to AND to_id=$uid");
        echo '{"ok":true,"status":"friend"}'; exit;
    }
    $st = $mysqli->prepare("INSERT IGNORE INTO lp_friends (from_id, to_id) VALUES (?,?)");
    $st->bind_param('ii', $uid, $to); $st->execute();
    if ($tg = tg_of($mysqli, $to)) {
        tg_ping($tg, "🐱 <b>" . htmlspecialchars($me['display_name']) . "</b> ne Meow Connect pe friend request bheji!\nApp kholo aur accept karo 👥");
    }
    echo '{"ok":true,"status":"sent"}'; exit;
}

if ($action === 'accept') {
    $from = (int)($b['from_id'] ?? 0);
    $st = $mysqli->prepare("UPDATE lp_friends SET status='accepted' WHERE from_id=? AND to_id=? AND status='pending'");
    $st->bind_param('ii', $from, $uid); $st->execute();
    if ($mysqli->affected_rows && ($tg = tg_of($mysqli, $from))) {
        tg_ping($tg, "🎉 <b>" . htmlspecialchars($me['display_name']) . "</b> ne aapki friend request accept kar li! Ab baat karo 💬");
    }
    echo json_encode(['ok' => (bool)$mysqli->affected_rows]); exit;
}

if ($action === 'remove') {
    $o = (int)($b['other_id'] ?? 0);
    $st = $mysqli->prepare("DELETE FROM lp_friends WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?)");
    $st->bind_param('iiii', $uid, $o, $o, $uid); $st->execute();
    echo '{"ok":true}'; exit;
}

if ($action === 'block') {
    $o = (int)($b['other_id'] ?? 0);
    $st = $mysqli->prepare("REPLACE INTO lp_blocks (user_id, blocked_id) VALUES (?,?)");
    $st->bind_param('ii', $uid, $o); $st->execute();
    $st = $mysqli->prepare("DELETE FROM lp_friends WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?)");
    $st->bind_param('iiii', $uid, $o, $o, $uid); $st->execute();
    echo '{"ok":true}'; exit;
}

if ($action === 'list') {
    $friends = []; $pin = []; $pout = [];
    $sql = "SELECT f.from_id, f.to_id, f.status,
                   p.user_id, p.display_name, p.username, p.my_language, p.learning_language, p.last_seen,
                   (SELECT COUNT(*) FROM lp_messages m WHERE m.from_id=p.user_id AND m.to_id=$uid AND m.seen=0 AND m.flagged=0) AS unread
            FROM lp_friends f
            JOIN lp_profiles p ON p.user_id = IF(f.from_id=$uid, f.to_id, f.from_id)
            WHERE f.from_id=$uid OR f.to_id=$uid";
    $res = $mysqli->query($sql);
    while ($r = $res->fetch_assoc()) {
        $item = [
            'user_id' => (int)$r['user_id'], 'display_name' => $r['display_name'],
            'username' => $r['username'], 'my_language' => $r['my_language'],
            'learning_language' => $r['learning_language'],
            'online' => (strtotime($r['last_seen']) > time() - 60) ? 1 : 0,
            'unread' => (int)$r['unread'],
        ];
        if ($r['status'] === 'accepted') $friends[] = $item;
        elseif ((int)$r['from_id'] === $uid) $pout[] = $item;
        else $pin[] = $item;
    }
    echo json_encode(['ok' => true, 'friends' => $friends, 'pending_in' => $pin, 'pending_out' => $pout], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'unknown action']);
