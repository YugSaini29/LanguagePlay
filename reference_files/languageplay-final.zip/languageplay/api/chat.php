<?php
/**
 * Language Play — Meow Guru multi-language proxy
 * Rocket Examica · Tech Eagles · Mahakumbrix Innovation
 *
 * POST: { "history":[...], "level":"beginner|advanced", "target":"Tamil" }
 * Out:  { ok, data:{ reply_speak, reply_roman, meaning_english,
 *                    corrected_sentence, mini_tip, praise_level } }
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'POST only']); exit;
}

require __DIR__ . '/config.php';

/* ---------- rate limit 20/min ---------- */
session_start();
$now = time();
$_SESSION['hits'] = array_values(array_filter($_SESSION['hits'] ?? [], fn($t) => $t > $now - 60));
if (count($_SESSION['hits']) >= 20) {
    http_response_code(429);
    echo json_encode(['ok' => false, 'error' => 'Thoda ruko! 😺']); exit;
}
$_SESSION['hits'][] = $now;

/* ---------- input ---------- */
$body = json_decode(file_get_contents('php://input'), true);
if (!$body || !isset($body['history']) || !is_array($body['history'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Bad request']); exit;
}
$level = ($body['level'] ?? 'beginner') === 'advanced' ? 'advanced' : 'beginner';
$user_key = preg_replace('/[^a-f0-9]/', '', (string)($body['user_key'] ?? ''));
$today = (new DateTime('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d');

/* target & source: koi bhi language name — sanitize */
function cleanLang($s){
    $s = preg_replace('/[^A-Za-z \-\(\)]/', '', (string)$s);
    return trim(mb_substr($s, 0, 30));
}
$target = cleanLang($body['target'] ?? 'English'); if ($target === '') $target = 'English';
$source = cleanLang($body['source'] ?? 'English'); if ($source === '') $source = 'English';

$history = array_slice($body['history'], -8);
$messages = [];
foreach ($history as $m) {
    $role = ($m['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
    $content = mb_substr(trim((string)($m['content'] ?? '')), 0, 600);
    if ($content !== '') $messages[] = ['role' => $role, 'content' => $content];
}
if (!$messages) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Empty message']); exit;
}

/* ---------- system prompt ---------- */
$levelNote = $level === 'beginner'
    ? "Teach slowly: ONE short {$target} phrase at a time, ask the learner to repeat it. Keep {$target} sentences 3-6 words."
    : "Have a flowing conversation mostly in {$target}, but still correct mistakes.";

$signNote = '';
if (stripos($target, 'Sign') !== false) {
    $signNote = "\nSPECIAL — SIGN LANGUAGE MODE (Indian Sign Language / ISL): "
        . "reply_speak must be a SHORT, CLEAR step-by-step description in simple English of how to perform ONE ISL sign "
        . "(handshape, location, movement — e.g. \"HELLO: Open palm near your forehead, move it outward like a salute\"). "
        . "Teach one sign at a time. reply_roman must be empty. reply_source = description translated to {$source}. "
        . "user_in_target = the ISL sign description for what the learner said. Never invent uncertain signs — stick to common, well-known ISL signs (hello, thank you, yes, no, water, food, family, numbers, alphabet fingerspelling).";
}

$system = <<<SYS
You are "Meow Guru" 🐱 — a warm, playful cat language teacher from Mahakumbrix Innovation.
The learner SPEAKS {$source} (source language) and WANTS TO LEARN {$target} (target language). English is the universal bridge.

ALWAYS reply with ONLY a valid JSON object, no markdown, no extra text:
{
  "user_in_target": "Translate the learner's LAST message into {$target} (native script) — this teaches them how to say what they just said. Empty string if their message was already in {$target}.",
  "user_roman": "Roman/Latin transliteration of user_in_target. Empty if user_in_target is empty or already Latin script.",
  "user_english": "The learner's last message in simple English. Empty if it was already English.",
  "reply_speak": "Your reply in {$target} using its NATIVE SCRIPT. Short and simple — this is spoken aloud by TTS. {$levelNote}",
  "reply_roman": "Roman/Latin transliteration of reply_speak. If {$target} already uses Latin script, repeat reply_speak.",
  "reply_source": "reply_speak translated into {$source} (native script) so the learner fully understands. If {$source} is English, same as reply_english.",
  "reply_english": "reply_speak meaning in simple English (1 line).",
  "corrected_sentence": "If the learner attempted {$target} and made a mistake, the corrected {$target} version: native script + (roman in brackets). Empty string \"\" otherwise.",
  "mini_tip": "One tiny pronunciation/grammar tip in simple English. Empty string if none.",
  "praise_level": 1 to 3 (3 = perfect attempt, 2 = good try, 1 = needs practice — ALWAYS kind),
  "reminder_detected": null OR {"title":"short task name","date":"YYYY-MM-DD"} — ONLY if the learner casually mentions a real-life date-based task (vehicle pollution/PUC, insurance renewal, EMI, exam, birthday, appointment, rent, bill). Today is {$today}. Convert relative dates ("agle mahine", "15 tarikh ko") to absolute YYYY-MM-DD. Otherwise null.
}

RULES:
1. Understand the learner's intent in {$source} (or any language), respond as a {$target} teacher continuing a natural conversation with a small follow-up question or a repeat-after-me task.
2. Keep {$target} simple (A1-A2 level). Everyday topics: greetings, family, food, numbers, shopping, travel.
3. Sprinkle ONE cat touch occasionally ("meow!") — max once per reply.
4. NEVER shame the learner. Praise effort first.
5. If the learner's message is "(session_start)", greet them warmly and teach the very first {$target} greeting word.{$signNote}
SYS;

array_unshift($messages, ['role' => 'system', 'content' => $system]);

/* ---------- Multi-provider call with auto-fallback ---------- */
if (defined('PROVIDERS')) {
    $providers = PROVIDERS;
} else {
    $providers = [['url' => 'https://openrouter.ai/api/v1/chat/completions',
                   'key' => OPENROUTER_KEY, 'model' => OR_MODEL]];
}

$resp = null; $err = null; $code = 0;

foreach ($providers as $p) {
    if (empty($p['key']) || strpos($p['key'], 'PASTE') !== false) continue;

    $req = [
        'model' => $p['model'],
        'messages' => $messages,
        'temperature' => 0.7,
        'max_tokens' => 500,
    ];
    if (empty($p['no_json_mode'])) $req['response_format'] = ['type' => 'json_object'];
    $payload = json_encode($req);

    $ch = curl_init($p['url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_TIMEOUT => 40,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $p['key'],
            'HTTP-Referer: https://languageplay.in',
            'X-Title: Language Play',
        ],
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$err && $code < 400 && $resp) break;
}

if ($err || $code >= 400 || !$resp) {
    http_response_code(502);
    echo json_encode(['ok' => false, 'error' => 'Meow Guru so gaya 😴', 'detail' => $err ?: "HTTP $code (all providers)"]);
    exit;
}

$out = json_decode($resp, true);
$text = $out['choices'][0]['message']['content'] ?? '';
$text = preg_replace('/^```(json)?|```$/m', '', trim($text));
$data = json_decode($text, true);

if (!is_array($data) || !isset($data['reply_speak'])) {
    $data = [
        'user_in_target' => '', 'user_roman' => '', 'user_english' => '',
        'reply_speak' => trim($text) !== '' ? mb_substr(trim($text), 0, 300) : "Sorry! Can you say that again?",
        'reply_roman' => '', 'reply_source' => '', 'reply_english' => '',
        'corrected_sentence' => '', 'mini_tip' => '', 'praise_level' => 2,
    ];
}

$data = [
    'user_in_target'     => (string)($data['user_in_target'] ?? ''),
    'user_roman'         => (string)($data['user_roman'] ?? ''),
    'user_english'       => (string)($data['user_english'] ?? ''),
    'reply_speak'        => (string)($data['reply_speak'] ?? ''),
    'reply_roman'        => (string)($data['reply_roman'] ?? ''),
    'reply_source'       => (string)($data['reply_source'] ?? ''),
    'reply_english'      => (string)($data['reply_english'] ?? ''),
    'corrected_sentence' => (string)($data['corrected_sentence'] ?? ''),
    'mini_tip'           => (string)($data['mini_tip'] ?? ''),
    'praise_level'       => max(1, min(3, (int)($data['praise_level'] ?? 2))),
];

/* ---------- P3: reminder + streak (DB optional — fail hone par bhi learning chalti hai) ---------- */
$reminder_saved = null; $reminder_offer = false;
$detected = null;
$rawParsed = json_decode($text, true);
if (is_array($rawParsed) && !empty($rawParsed['reminder_detected']['title']) && !empty($rawParsed['reminder_detected']['date'])) {
    $detected = [
        'title' => mb_substr((string)$rawParsed['reminder_detected']['title'], 0, 200),
        'date'  => (string)$rawParsed['reminder_detected']['date'],
    ];
}
if ($detected || strlen($user_key) === 32) {
    $db = @new mysqli('localhost', 'admin', 'StrongPassword123!', 'eagle_auth');
    if ($db && !$db->connect_error) {
        $db->set_charset('utf8mb4');
        $uid = null;
        if (strlen($user_key) === 32) {
            $st = $db->prepare("SELECT id FROM lp_users WHERE user_key=?");
            $st->bind_param('s', $user_key); $st->execute();
            if ($r = $st->get_result()->fetch_assoc()) $uid = (int)$r['id'];
        }
        if ($uid) {
            /* streak + xp */
            $db->query("INSERT INTO lp_progress (user_id, xp, streak_days, last_active, target_lang)
                        VALUES ($uid, 5, 1, CURDATE(), '" . $db->real_escape_string($target) . "')
                        ON DUPLICATE KEY UPDATE
                          streak_days = IF(last_active = CURDATE() - INTERVAL 1 DAY, streak_days + 1,
                                        IF(last_active = CURDATE(), streak_days, 1)),
                          last_active = CURDATE(), xp = xp + 5,
                          target_lang = VALUES(target_lang)");
        }
        if ($detected) {
            $d = DateTime::createFromFormat('Y-m-d', $detected['date']);
            if ($d && $d->format('Y-m-d') >= $today) {
                $linked = false;
                if ($uid) {
                    $st = $db->prepare("SELECT 1 FROM lp_links WHERE user_id=?");
                    $st->bind_param('i', $uid); $st->execute();
                    $linked = (bool)$st->get_result()->fetch_row();
                }
                if ($uid && $linked) {
                    $st = $db->prepare("INSERT INTO lp_reminders (user_id, title, due_date, created_via) VALUES (?,?,?,'chat')");
                    $st->bind_param('iss', $uid, $detected['title'], $detected['date']);
                    $st->execute();
                    $reminder_saved = $detected;
                } else {
                    $reminder_offer = true;
                }
            }
        }
        $db->close();
    }
}
$data['reminder_saved'] = $reminder_saved;
$data['reminder_offer'] = $reminder_offer;

echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
