<?php
/**
 * config.php — ab sirf fallback.php ko load karta hai.
 * SAARI KEYS fallback.php me daalo (wahi master file hai).
 */
require_once __DIR__ . '/fallback.php';
