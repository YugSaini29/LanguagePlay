<?php
/** Shared LLM caller — provider chain se (config.php PROVIDERS) */
require_once __DIR__ . '/config.php';

function call_llm(array $messages, int $max_tokens = 400, float $temp = 0.4): ?array {
    $providers = defined('PROVIDERS') ? PROVIDERS : [];
    foreach ($providers as $p) {
        if (empty($p['key']) || strpos($p['key'], 'PASTE') !== false) continue;
        $req = ['model' => $p['model'], 'messages' => $messages,
                'temperature' => $temp, 'max_tokens' => $max_tokens,
                'response_format' => ['type' => 'json_object']];
        $ch = curl_init($p['url']);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($req), CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $p['key'],
                'HTTP-Referer: https://languageplay.in',
                'X-Title: Language Play Connect'],
        ]);
        $resp = curl_exec($ch);
        $err = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($err || $code >= 400 || !$resp) continue;
        $out = json_decode($resp, true);
        $text = $out['choices'][0]['message']['content'] ?? '';
        $text = preg_replace('/^```(json)?|```$/m', '', trim($text));
        $data = json_decode($text, true);
        if (is_array($data)) return $data;
    }
    return null;
}
