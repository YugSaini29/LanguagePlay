<?php
/**
 * Meow Guru — Server Self-Test v2 (saare providers test karta hai)
 * Browser me kholo:  https://examica.in/meowguru/api/test.php
 * Fix hone ke baad DELETE karo:  sudo rm test.php
 */
header('Content-Type: text/html; charset=utf-8');
set_time_limit(120);
echo "<html><body style='font-family:sans-serif;max-width:680px;margin:30px auto;line-height:1.7;font-size:15px'>";
echo "<h2>🐱 Meow Guru — Server Test v2</h2>";

function ok($m){ echo "✅ $m<br>"; }
function bad($m,$fix=''){ echo "❌ <b>$m</b><br>"; if($fix) echo "&nbsp;&nbsp;&nbsp;🔧 <code>$fix</code><br>"; }

ok("PHP " . PHP_VERSION);
if (!file_exists(__DIR__ . '/config.php')) { bad("config.php missing"); exit("</body></html>"); }
require __DIR__ . '/config.php';
if (!function_exists('curl_init')) { bad("php-curl missing", "sudo apt install php-curl -y && sudo systemctl restart apache2"); exit("</body></html>"); }
ok("config.php + php-curl OK");

if (!defined('PROVIDERS')) { bad("config.php me PROVIDERS defined nahi hai — nayi zip ki config use karo"); exit("</body></html>"); }

echo "<hr><b>🧪 Har provider ka live test:</b><br><br>";
$anyPass = false;

foreach (PROVIDERS as $i => $p) {
    $n = $i + 1;
    $host = parse_url($p['url'], PHP_URL_HOST);
    $label = "#$n <b>$host</b> · <code>{$p['model']}</code>";

    if (empty($p['key']) || strpos($p['key'], 'PASTE') !== false) {
        echo "⏭️ $label — key nahi dali, skip<br><br>"; continue;
    }
    $mk = substr($p['key'],0,8) . "..." . substr($p['key'],-4);

    $req = ['model'=>$p['model'],
            'messages'=>[['role'=>'user','content'=>'Reply with json only: {"test":"ok"}']],
            'max_tokens'=>30];
    if (empty($p['no_json_mode'])) $req['response_format'] = ['type'=>'json_object'];

    $t0 = microtime(true);
    $ch = curl_init($p['url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>json_encode($req), CURLOPT_TIMEOUT=>30,
        CURLOPT_HTTPHEADER=>[
            'Content-Type: application/json',
            'Authorization: Bearer '.$p['key'],
            'HTTP-Referer: https://examica.in',
            'X-Title: Meow Guru Test',
        ],
    ]);
    $resp = curl_exec($ch);
    $err = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $secs = round(microtime(true)-$t0, 1);

    if ($err) { bad("$label — curl error: $err"); }
    elseif ($code == 401) { bad("$label — KEY GALAT/INVALID (401), key: $mk", "Is provider ki nayi key banao"); }
    elseif ($code == 402) { bad("$label — credits nahi (402)"); }
    elseif ($code == 429) { bad("$label — busy/rate-limit (429) — abhi ye provider full hai"); }
    elseif ($code >= 400) {
        $e = json_decode($resp, true);
        $msg = $e['error']['message'] ?? substr(strip_tags((string)$resp),0,150);
        bad("$label — HTTP $code: " . htmlspecialchars($msg));
    } else {
        $out = json_decode($resp, true);
        $txt = $out['choices'][0]['message']['content'] ?? '(empty)';
        ok("$label — <b style='color:green'>WORKING</b> ({$secs}s): <code>".htmlspecialchars(substr($txt,0,60))."</code>");
        $anyPass = true;
    }
    echo "<br>";
}

echo "<hr>";
if ($anyPass) {
    echo "<h3 style='color:green'>🎉 Kam se kam ek provider chal raha hai — app ko chalna chahiye!</h3>";
    echo "Agar app me phir bhi 'server problem' aaye:<br>
          1. Kya aapne nayi zip deploy ki? (<code>sudo rm -rf /var/www/html/meowguru</code> phir unzip)<br>
          2. Phone me app kholo → jab error aaye → mujhe batao kya EXACT message hai<br>
          3. Browser me kholo: <code>https://examica.in/meowguru/api/chat.php</code> — 'POST only' dikhna chahiye";
} else {
    echo "<h3 style='color:red'>😿 Koi bhi provider nahi chala — upar wale ❌ ke fixes karo</h3>";
}
echo "<br><small>⚠️ Fix ke baad: <code>sudo rm /var/www/html/meowguru/api/test.php</code></small>";
echo "</body></html>";
