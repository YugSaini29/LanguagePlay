<?php
/** Meow Connect — profiles, search, presence, lounge (18+ gate) */
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo '{"ok":false}'; exit; }
require __DIR__ . '/dbconfig.php';

$b = json_decode(file_get_contents('php://input'), true) ?: [];
$action = (string)($b['action'] ?? '');
$u = ensure_user($mysqli, (string)($b['user_key'] ?? ''));
$uid = (int)$u['id'];

function my_profile(mysqli $db, int $uid): ?array {
    $st = $db->prepare("SELECT user_id, display_name, username, my_language, learning_language,
                        birth_date, is_adult, is_banned, searchable_by_mobile, searchable_by_name
                        FROM lp_profiles WHERE user_id=?");
    $st->bind_param('i', $uid); $st->execute();
    return $st->get_result()->fetch_assoc() ?: null;
}

/* presence heartbeat har call pe */
$mysqli->query("UPDATE lp_profiles SET last_seen=NOW() WHERE user_id=$uid");

if ($action === 'me') {
    $pic = '';
    $pr = @$mysqli->query("SELECT picture FROM lp_users WHERE id=$uid");
    if ($pr && ($pw = $pr->fetch_assoc())) $pic = (string)($pw['picture'] ?? '');
    echo json_encode(['ok' => true, 'user_key' => $u['user_key'],
                      'profile' => my_profile($mysqli, $uid), 'picture' => $pic]);
    exit;
}

if ($action === 'setup') {
    $name = mb_substr(trim((string)($b['display_name'] ?? '')), 0, 50);
    $uname = strtolower(preg_replace('/[^a-z0-9_]/', '', (string)($b['username'] ?? '')));
    $uname = substr($uname, 0, 30);
    $bd = (string)($b['birth_date'] ?? '');
    $myL = mb_substr(preg_replace('/[^A-Za-z \-\(\)]/', '', (string)($b['my_language'] ?? 'English')), 0, 30);
    $lrnL = mb_substr(preg_replace('/[^A-Za-z \-\(\)]/', '', (string)($b['learning_language'] ?? 'English')), 0, 30);
    $mobile = preg_replace('/\D/', '', (string)($b['mobile'] ?? ''));
    $smob = !empty($b['searchable_by_mobile']) ? 1 : 0;

    $d = DateTime::createFromFormat('Y-m-d', $bd);
    if (!$name || strlen($uname) < 3 || !$d) {
        echo json_encode(['ok' => false, 'error' => 'Name, username (3+ chars) aur date of birth zaroori hai']); exit;
    }
    $age = $d->diff(new DateTime('now'))->y;
    $is_adult = $age >= 18 ? 1 : 0;
    $mh = (strlen($mobile) >= 10) ? hash('sha256', substr($mobile, -10)) : null;

    /* username uniqueness (khud ko chhod ke) */
    $st = $mysqli->prepare("SELECT user_id FROM lp_profiles WHERE username=? AND user_id<>?");
    $st->bind_param('si', $uname, $uid); $st->execute();
    if ($st->get_result()->fetch_row()) { echo json_encode(['ok' => false, 'error' => 'Username pehle se liya hai']); exit; }

    $st = $mysqli->prepare(
        "REPLACE INTO lp_profiles (user_id, display_name, username, mobile_hash, my_language,
         learning_language, birth_date, is_adult, searchable_by_mobile, last_seen)
         VALUES (?,?,?,?,?,?,?,?,?,NOW())");
    $st->bind_param('issssssii', $uid, $name, $uname, $mh, $myL, $lrnL, $bd, $is_adult, $smob);
    $st->execute();
    echo json_encode(['ok' => true, 'user_key' => $u['user_key'], 'profile' => my_profile($mysqli, $uid)]);
    exit;
}

/* ---- neeche ke actions: adults only ---- */
$me = my_profile($mysqli, $uid);
if (!$me || !$me['is_adult']) { echo json_encode(['ok' => false, 'error' => 'adult_only']); exit; }
if (!empty($me['is_banned'])) { echo json_encode(['ok' => false, 'error' => 'Account blocked — contact support']); exit; }

function friend_status(mysqli $db, int $a, int $b): string {
    $st = $db->prepare("SELECT status, from_id FROM lp_friends WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?)");
    $st->bind_param('iiii', $a, $b, $b, $a); $st->execute();
    $r = $st->get_result()->fetch_assoc();
    if (!$r) return 'none';
    if ($r['status'] === 'accepted') return 'friend';
    return ((int)$r['from_id'] === $a) ? 'sent' : 'incoming';
}

if ($action === 'langs') {
    $my = trim((string)($b['my_language'] ?? ''));
    $lr = trim((string)($b['learning_language'] ?? ''));
    if ($my === '' || $lr === '') { echo json_encode(['ok' => false, 'error' => 'Bhasha chuno']); exit; }
    $my = mb_substr($my, 0, 40);
    $lr = mb_substr($lr, 0, 40);
    $st = $mysqli->prepare("UPDATE lp_profiles SET my_language=?, learning_language=? WHERE user_id=?");
    $st->bind_param('ssi', $my, $lr, $uid);
    $st->execute();
    echo json_encode(['ok' => true]);
    exit;
}

if ($action === 'search') {
    $type = (string)($b['type'] ?? 'name');
    $qs = trim((string)($b['query'] ?? ''));
    if ($qs === '') { echo json_encode(['ok' => true, 'results' => []]); exit; }
    $rows = [];
    if ($type === 'mobile') {
        $digits = preg_replace('/\D/', '', $qs);
        if (strlen($digits) < 10) { echo json_encode(['ok' => false, 'error' => 'Pura 10-digit number do']); exit; }
        $mh = hash('sha256', substr($digits, -10));
        $st = $mysqli->prepare("SELECT user_id, display_name, username, my_language, learning_language, last_seen
                                FROM lp_profiles WHERE mobile_hash=? AND searchable_by_mobile=1 AND is_adult=1 AND user_id<>? LIMIT 5");
        $st->bind_param('si', $mh, $uid);
    } elseif ($type === 'telegram') {
        $tg = ltrim($qs, '@');
        $st = $mysqli->prepare("SELECT p.user_id, p.display_name, p.username, p.my_language, p.learning_language, p.last_seen
                                FROM lp_profiles p JOIN lp_links l ON l.user_id=p.user_id
                                WHERE l.telegram_username=? AND p.is_adult=1 AND p.user_id<>? LIMIT 5");
        $st->bind_param('si', $tg, $uid);
    } else {
        $like = '%' . $qs . '%';
        $st = $mysqli->prepare("SELECT user_id, display_name, username, my_language, learning_language, last_seen
                                FROM lp_profiles
                                WHERE (display_name LIKE ? OR username LIKE ?) AND searchable_by_name=1 AND is_adult=1 AND user_id<>?
                                ORDER BY last_seen DESC LIMIT 10");
        $st->bind_param('ssi', $like, $like, $uid);
    }
    $st->execute();
    $res = $st->get_result();
    while ($r = $res->fetch_assoc()) {
        $r['online'] = (strtotime($r['last_seen']) > time() - 60) ? 1 : 0;
        $r['friend_status'] = friend_status($mysqli, $uid, (int)$r['user_id']);
        unset($r['last_seen']);
        $rows[] = $r;
    }
    echo json_encode(['ok' => true, 'results' => $rows], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'lounge') {
    /* exchange match: uski my = meri learning AND uski learning = meri my */
    $st = $mysqli->prepare("SELECT user_id, display_name, username, my_language, learning_language, last_seen
                            FROM lp_profiles
                            WHERE my_language=? AND learning_language=? AND is_adult=1 AND user_id<>?
                            ORDER BY last_seen DESC LIMIT 10");
    $st->bind_param('ssi', $me['learning_language'], $me['my_language'], $uid);
    $st->execute();
    $res = $st->get_result(); $rows = [];
    while ($r = $res->fetch_assoc()) {
        $r['online'] = (strtotime($r['last_seen']) > time() - 60) ? 1 : 0;
        $r['friend_status'] = friend_status($mysqli, $uid, (int)$r['user_id']);
        unset($r['last_seen']);
        $rows[] = $r;
    }
    echo json_encode(['ok' => true, 'results' => $rows], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'unknown action']);
