<?php
/** Quiz Mode — MCQ generator + XP award */
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo '{"ok":false}'; exit; }
require __DIR__ . '/llm.php';

$b = json_decode(file_get_contents('php://input'), true) ?: [];
$action = (string)($b['action'] ?? 'gen');

function cleanL($s){ $s = preg_replace('/[^A-Za-z \-\(\)]/', '', (string)$s); return trim(mb_substr($s,0,30)) ?: 'English'; }

if ($action === 'award') {
    $user_key = preg_replace('/[^a-f0-9]/', '', (string)($b['user_key'] ?? ''));
    $pts = max(1, min(20, (int)($b['points'] ?? 5)));
    if (strlen($user_key) === 32) {
        $db = @new mysqli('localhost', 'admin', 'StrongPassword123!', 'eagle_auth');
        if ($db && !$db->connect_error) {
            $st = $db->prepare("SELECT id FROM lp_users WHERE user_key=?");
            $st->bind_param('s', $user_key); $st->execute();
            if ($r = $st->get_result()->fetch_assoc()) {
                $uid = (int)$r['id'];
                $db->query("INSERT INTO lp_progress (user_id, xp, streak_days, last_active)
                            VALUES ($uid, $pts, 1, CURDATE())
                            ON DUPLICATE KEY UPDATE xp = xp + $pts,
                              streak_days = IF(last_active = CURDATE() - INTERVAL 1 DAY, streak_days + 1,
                                            IF(last_active = CURDATE(), streak_days, 1)),
                              last_active = CURDATE()");
            }
            $db->close();
        }
    }
    echo '{"ok":true}'; exit;
}

/* gen */
$target = cleanL($b['target'] ?? 'English');
$source = cleanL($b['source'] ?? 'English');
$level  = ($b['level'] ?? 'beginner') === 'advanced' ? 'advanced' : 'beginner';
$avoid = [];
foreach ((array)($b['avoid'] ?? []) as $a) {
    if (is_string($a) && trim($a) !== '') $avoid[] = mb_substr(trim($a), 0, 200);
    if (count($avoid) >= 6) break;
}
$TOPICS = ['greetings','numbers 1-20','food & drinks','family members','colors','days & months',
           'common verbs','shopping & money','travel & directions','animals','body parts',
           'weather','question words','polite phrases','time & clock','clothes','emotions',
           'school & work','house & rooms','hobbies'];
$topic = $TOPICS[array_rand($TOPICS)];
$diff = $level === 'beginner' ? 'very easy A1 (greetings, numbers, food, family, colors)' : 'A2-B1 (sentences, verbs, daily situations)';

$sys = "You create ONE multiple-choice quiz question for a {$source}-speaking learner studying {$target}. "
     . "Difficulty: {$diff}. TOPIC for this question: {$topic}. Make it fresh and different. Reply ONLY JSON: "
     . "{\"question\":\"question in {$source} (short, fun, may include a {$target} word to translate)\","
     . "\"options\":[{\"t\":\"option in {$target} native script\",\"r\":\"roman transliteration\"},... exactly 4],"
     . "\"correct\":0-3 (index of right answer),"
     . "\"explain\":\"1-line why, in simple {$source}\"}";

$userMsg = 'New quiz question on topic "' . $topic . '". Random seed: ' . random_int(1, 99999);
if ($avoid) $userMsg .= ' Do NOT repeat or resemble these previous questions: ' . json_encode($avoid, JSON_UNESCAPED_UNICODE);
$out = call_llm([
    ['role' => 'system', 'content' => $sys],
    ['role' => 'user', 'content' => $userMsg],
], 400, 0.95);

if (!is_array($out) || empty($out['options']) || count($out['options']) !== 4 || !isset($out['correct'])) {
    echo json_encode(['ok' => false, 'error' => 'Quiz ban nahi paya — dubara try karo']); exit;
}
$opts = [];
foreach ($out['options'] as $o) {
    $opts[] = ['t' => (string)($o['t'] ?? ''), 'r' => (string)($o['r'] ?? '')];
}
echo json_encode(['ok' => true, 'quiz' => [
    'question' => (string)($out['question'] ?? ''),
    'options' => $opts,
    'correct' => max(0, min(3, (int)$out['correct'])),
    'explain' => (string)($out['explain'] ?? ''),
]], JSON_UNESCAPED_UNICODE);
