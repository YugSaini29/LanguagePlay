<?php
/** Meow Connect — friends-only cross-language chat (translate + safety + offline ping) */
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo '{"ok":false}'; exit; }
require __DIR__ . '/dbconfig.php';
require __DIR__ . '/llm.php';

$b = json_decode(file_get_contents('php://input'), true) ?: [];
$action = (string)($b['action'] ?? '');
$u = ensure_user($mysqli, (string)($b['user_key'] ?? ''));
$uid = (int)$u['id'];

$st = $mysqli->prepare("SELECT display_name, my_language, is_adult, is_banned FROM lp_profiles WHERE user_id=?");
$st->bind_param('i', $uid); $st->execute();
$me = $st->get_result()->fetch_assoc();
if (!$me || !$me['is_adult']) { echo json_encode(['ok' => false, 'error' => 'adult_only']); exit; }
if (!empty($me['is_banned'])) { echo json_encode(['ok' => false, 'error' => 'Account blocked']); exit; }
$mysqli->query("UPDATE lp_profiles SET last_seen=NOW() WHERE user_id=$uid");

function are_friends(mysqli $db, int $a, int $b): bool {
    $st = $db->prepare("SELECT 1 FROM lp_friends WHERE status='accepted' AND ((from_id=? AND to_id=?) OR (from_id=? AND to_id=?))");
    $st->bind_param('iiii', $a, $b, $b, $a); $st->execute();
    return (bool)$st->get_result()->fetch_row();
}

if ($action === 'send') {
    $to = (int)($b['to_id'] ?? 0);
    $text = mb_substr(trim((string)($b['text'] ?? '')), 0, 500);
    if (!$to || $text === '' || !are_friends($mysqli, $uid, $to)) {
        echo json_encode(['ok' => false, 'error' => 'Sirf friends ko message bhej sakte ho']); exit;
    }
    /* rate limit: 30/min */
    $res = $mysqli->query("SELECT COUNT(*) c FROM lp_messages WHERE from_id=$uid AND created_at > NOW() - INTERVAL 60 SECOND");
    if ((int)$res->fetch_assoc()['c'] >= 30) { echo json_encode(['ok' => false, 'error' => 'Thoda dheere! 😺']); exit; }

    $st = $mysqli->prepare("SELECT display_name, my_language, last_seen FROM lp_profiles WHERE user_id=? AND is_adult=1");
    $st->bind_param('i', $to); $st->execute();
    $peer = $st->get_result()->fetch_assoc();
    if (!$peer) { echo '{"ok":false,"error":"invalid"}'; exit; }

    /* translate + safety — ek LLM call */
    $sys = "You translate chat messages between language-exchange partners. "
         . "Translate the user's message from {$me['my_language']} to {$peer['my_language']}. "
         . "Reply ONLY JSON: {\"translated\":\"in {$peer['my_language']} native script\","
         . "\"roman\":\"Latin transliteration (repeat translated if already Latin)\","
         . "\"english\":\"English meaning\","
         . "\"safe\":true/false — false ONLY if abusive, sexual, threatening, or asks to move to another platform/share personal contact details}";
    $out = call_llm([
        ['role' => 'system', 'content' => $sys],
        ['role' => 'user', 'content' => $text],
    ], 350);

    $translated = (string)($out['translated'] ?? $text);
    $roman = (string)($out['roman'] ?? '');
    $english = (string)($out['english'] ?? '');
    $safe = !isset($out['safe']) || $out['safe'] === true;

    $flag = $safe ? 0 : 1;
    $st = $mysqli->prepare(
        "INSERT INTO lp_messages (from_id, to_id, original_text, original_lang, translated_text, translated_roman, english_text, flagged)
         VALUES (?,?,?,?,?,?,?,?)");
    $ol = $me['my_language'];
    $st->bind_param('iisssssi', $uid, $to, $text, $ol, $translated, $roman, $english, $flag);
    $st->execute();
    $mid = $mysqli->insert_id;

    if (!$safe) {
        echo json_encode(['ok' => false, 'error' => '😿 Message deliver nahi hua — Meow ko ye theek nahi laga. Pyaar se baat karo!']); exit;
    }
    /* offline friend → Telegram ping */
    $offline = strtotime($peer['last_seen']) < time() - 60;
    if ($offline) {
        $st = $mysqli->prepare("SELECT telegram_chat_id FROM lp_links WHERE user_id=?");
        $st->bind_param('i', $to); $st->execute();
        if ($lr = $st->get_result()->fetch_assoc()) {
            tg_ping((int)$lr['telegram_chat_id'],
                "💬 <b>" . htmlspecialchars($me['display_name']) . "</b> ne Meow Connect pe message bheja!\nApp kholke reply karo 🐱");
        }
    }
    echo json_encode(['ok' => true, 'message' => [
        'id' => $mid, 'from_id' => $uid, 'original_text' => $text,
        'translated_text' => $translated, 'translated_roman' => $roman, 'english_text' => $english,
    ]], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'fetch') {
    $peer = (int)($b['peer_id'] ?? 0);
    $after = (int)($b['after_id'] ?? 0);
    if (!$peer || !are_friends($mysqli, $uid, $peer)) { echo '{"ok":false,"error":"invalid"}'; exit; }
    $st = $mysqli->prepare(
        "SELECT id, from_id, original_text, original_lang, translated_text, translated_roman, english_text, created_at
         FROM lp_messages
         WHERE flagged=0 AND id>? AND ((from_id=? AND to_id=?) OR (from_id=? AND to_id=?))
         ORDER BY id LIMIT 50");
    $st->bind_param('iiiii', $after, $uid, $peer, $peer, $uid);
    $st->execute();
    $res = $st->get_result(); $msgs = [];
    while ($r = $res->fetch_assoc()) $msgs[] = $r;
    $mysqli->query("UPDATE lp_messages SET seen=1 WHERE to_id=$uid AND from_id=$peer AND seen=0");
    $st = $mysqli->prepare("SELECT last_seen FROM lp_profiles WHERE user_id=?");
    $st->bind_param('i', $peer); $st->execute();
    $p = $st->get_result()->fetch_assoc();
    echo json_encode(['ok' => true, 'messages' => $msgs,
        'peer_online' => ($p && strtotime($p['last_seen']) > time() - 60) ? 1 : 0], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'report') {
    $st = $mysqli->prepare("INSERT INTO lp_reports (reporter_id, reported_id, message_id, reason) VALUES (?,?,?,?)");
    $rid = (int)($b['reported_id'] ?? 0); $mid = (int)($b['message_id'] ?? 0);
    $reason = mb_substr((string)($b['reason'] ?? ''), 0, 200);
    $st->bind_param('iiis', $uid, $rid, $mid, $reason);
    $st->execute();
    echo '{"ok":true}'; exit;
}

echo json_encode(['ok' => false, 'error' => 'unknown action']);
