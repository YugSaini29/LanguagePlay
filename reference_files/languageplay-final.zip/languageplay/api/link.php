<?php
/**
 * Eagle Login — Telegram linking (PHP side)
 * Same HMAC-SHA1 / 180s / 6-digit algorithm as bot/eagle_totp.py
 *
 * POST {} ya {"user_key":"..."} → {ok, user_key, code, bot, expires_in}
 */
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'POST only']); exit;
}

require __DIR__ . '/dbconfig.php';   // $mysqli + BOT_USERNAME

/* ---------- Eagle TOTP (PHP) ---------- */
function b32_decode(string $s): string {
    $map = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $s = strtoupper(rtrim($s, '='));
    $bits = '';
    foreach (str_split($s) as $c) {
        $v = strpos($map, $c);
        if ($v === false) continue;
        $bits .= str_pad(decbin($v), 5, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 8) as $b) {
        if (strlen($b) === 8) $out .= chr(bindec($b));
    }
    return $out;
}
function eagle_totp(string $secret, int $period = 180, int $digits = 6): string {
    $counter = intdiv(time(), $period);
    $key = b32_decode($secret);
    $msg = pack('N*', 0) . pack('N*', $counter);
    $h = hash_hmac('sha1', $msg, $key, true);
    $o = ord($h[19]) & 0x0F;
    $code = (unpack('N', substr($h, $o, 4))[1] & 0x7FFFFFFF) % (10 ** $digits);
    return str_pad((string)$code, $digits, '0', STR_PAD_LEFT);
}
function new_secret(): string {
    $map = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $s = '';
    for ($i = 0; $i < 16; $i++) $s .= $map[random_int(0, 31)];
    return $s;
}

/* ---------- user find/create ---------- */
$body = json_decode(file_get_contents('php://input'), true) ?: [];
$user_key = preg_replace('/[^a-f0-9]/', '', (string)($body['user_key'] ?? ''));

$user = null;
if (strlen($user_key) === 32) {
    $st = $mysqli->prepare("SELECT id, user_key, totp_secret FROM lp_users WHERE user_key=?");
    $st->bind_param('s', $user_key);
    $st->execute();
    $user = $st->get_result()->fetch_assoc();
}
if (!$user) {
    $user_key = bin2hex(random_bytes(16));
    $secret = new_secret();
    $st = $mysqli->prepare("INSERT INTO lp_users (user_key, totp_secret) VALUES (?,?)");
    $st->bind_param('ss', $user_key, $secret);
    $st->execute();
    $user = ['id' => $mysqli->insert_id, 'user_key' => $user_key, 'totp_secret' => $secret];
}

/* ---------- issue code ---------- */
$code = eagle_totp($user['totp_secret']);
$mysqli->query("DELETE FROM lp_link_codes WHERE expires_at < NOW()");
$st = $mysqli->prepare(
    "REPLACE INTO lp_link_codes (code, user_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 180 SECOND))");
$st->bind_param('si', $code, $user['id']);
$st->execute();

echo json_encode([
    'ok' => true,
    'user_key' => $user['user_key'],
    'code' => $code,
    'bot' => BOT_USERNAME,
    'expires_in' => 180,
]);
