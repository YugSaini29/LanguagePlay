<?php
/** Leaderboard — top 20 by XP (sirf profile wale naam ke saath) */
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo '{"ok":false}'; exit; }
require __DIR__ . '/dbconfig.php';

$b = json_decode(file_get_contents('php://input'), true) ?: [];
$user_key = preg_replace('/[^a-f0-9]/', '', (string)($b['user_key'] ?? ''));

$rows = [];
$res = $mysqli->query(
    "SELECT g.xp, g.streak_days, COALESCE(p.display_name, CONCAT('Learner #', g.user_id)) AS name,
            g.user_id
     FROM lp_progress g LEFT JOIN lp_profiles p ON p.user_id = g.user_id
     ORDER BY g.xp DESC LIMIT 20");
$rank = 0;
while ($r = $res->fetch_assoc()) {
    $rank++;
    $rows[] = ['rank' => $rank, 'name' => $r['name'], 'xp' => (int)$r['xp'], 'streak' => (int)$r['streak_days']];
}

$mine = null;
if (strlen($user_key) === 32) {
    $st = $mysqli->prepare(
        "SELECT g.xp, (SELECT COUNT(*)+1 FROM lp_progress g2 WHERE g2.xp > g.xp) AS rnk
         FROM lp_progress g JOIN lp_users u ON u.id=g.user_id WHERE u.user_key=?");
    $st->bind_param('s', $user_key); $st->execute();
    if ($m = $st->get_result()->fetch_assoc()) {
        $mine = ['rank' => (int)$m['rnk'], 'xp' => (int)$m['xp']];
    }
}
echo json_encode(['ok' => true, 'top' => $rows, 'me' => $mine], JSON_UNESCAPED_UNICODE);
