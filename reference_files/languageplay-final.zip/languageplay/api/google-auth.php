<?php
/** Google Sign-In (GIS) — token verify + Eagle user linking
 *  GET ?cfg=1  → {ok, client_id}   (frontend init ke liye)
 *  POST {credential, user_key}     → verify + link → {ok, user_key, has_profile, name, email}
 */
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/dbconfig.php';

/* auto-migrate: lp_users me google_id + email columns */
$col = $mysqli->query("SELECT COUNT(*) c FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='lp_users' AND COLUMN_NAME='google_id'");
if ($col && (int)$col->fetch_assoc()['c'] === 0) {
    $mysqli->query("ALTER TABLE lp_users ADD COLUMN google_id VARCHAR(64) NULL UNIQUE, ADD COLUMN email VARCHAR(120) NULL");
}
$col2 = $mysqli->query("SELECT COUNT(*) c FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='lp_users' AND COLUMN_NAME='picture'");
if ($col2 && (int)$col2->fetch_assoc()['c'] === 0) {
    $mysqli->query("ALTER TABLE lp_users ADD COLUMN picture VARCHAR(300) NULL");
}

if (($_GET['cfg'] ?? '') === '1') {
    $cid = (defined('GOOGLE_CLIENT_ID') && strpos(GOOGLE_CLIENT_ID, 'PASTE') === false) ? GOOGLE_CLIENT_ID : '';
    echo json_encode(['ok' => true, 'client_id' => $cid]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo '{"ok":false}'; exit; }

$b = json_decode(file_get_contents('php://input'), true) ?: [];
$cred = (string)($b['credential'] ?? '');
if ($cred === '' || !defined('GOOGLE_CLIENT_ID')) { echo '{"ok":false,"error":"no credential"}'; exit; }

/* Google se token verify */
$ch = curl_init('https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($cred));
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10]);
$resp = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
$tok = json_decode((string)$resp, true);

if ($code !== 200 || !is_array($tok)
    || ($tok['aud'] ?? '') !== GOOGLE_CLIENT_ID
    || ($tok['email_verified'] ?? '') !== 'true'
    || (int)($tok['exp'] ?? 0) < time()) {
    echo json_encode(['ok' => false, 'error' => 'Google verification failed']); exit;
}

$gid   = (string)$tok['sub'];
$email = mb_substr((string)($tok['email'] ?? ''), 0, 120);
$name  = mb_substr((string)($tok['name'] ?? ''), 0, 50);
$pic   = mb_substr((string)($tok['picture'] ?? ''), 0, 300);
if ($pic && !preg_match('#^https://#', $pic)) $pic = '';

/* pehle se linked? → wahi account wapas (cross-device continuity) */
$st = $mysqli->prepare("SELECT id, user_key FROM lp_users WHERE google_id=?");
$st->bind_param('s', $gid);
$st->execute();
$u = $st->get_result()->fetch_assoc();

if (!$u) {
    $u = ensure_user($mysqli, (string)($b['user_key'] ?? ''));
    $st = $mysqli->prepare("UPDATE lp_users SET google_id=?, email=? WHERE id=? AND google_id IS NULL");
    $st->bind_param('ssi', $gid, $email, $u['id']);
    $st->execute();
    /* race/duplicate: kisi aur row pe already linked ho toh usi ko lo */
    if ($mysqli->affected_rows === 0) {
        $st = $mysqli->prepare("SELECT id, user_key FROM lp_users WHERE google_id=?");
        $st->bind_param('s', $gid); $st->execute();
        $u = $st->get_result()->fetch_assoc() ?: $u;
    }
}

/* picture har login pe refresh */
$st = $mysqli->prepare("UPDATE lp_users SET picture=? WHERE id=?");
$st->bind_param('si', $pic, $u['id']);
$st->execute();

$st = $mysqli->prepare("SELECT user_id FROM lp_profiles WHERE user_id=?");
$st->bind_param('i', $u['id']);
$st->execute();
$has_profile = (bool)$st->get_result()->fetch_row();

echo json_encode([
    'ok' => true,
    'user_key' => $u['user_key'],
    'has_profile' => $has_profile,
    'name' => $name,
    'email' => $email,
    'picture' => $pic,
], JSON_UNESCAPED_UNICODE);
