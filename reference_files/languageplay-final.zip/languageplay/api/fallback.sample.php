<?php
/**
 * ═══════════════════════════════════════════════════════════════
 *  FALLBACK.PHP — YAHI EK FILE ME SAARI KEYS DAALO (on the fly)
 *  Language Play · Rocket Examica · Mahakumbrix Innovation
 * ═══════════════════════════════════════════════════════════════
 *  Har provider me JITNI MARZI keys add karo — bas comma laga ke
 *  nayi line jodo. Save karte hi turant live (koi restart nahi).
 *
 *  • Multiple keys = zyada free quota (har key ka apna limit)
 *  • Keys minute-wise ROTATE hoti hain — load sab pe barabar
 *  • Khali [] chhodo toh wo provider auto-skip
 *  • Order: Tier1 FREE-FAST → Tier2 FREE-BACKUP → Tier3 PAID
 */

/* ── GROQ (console.groq.com) — FREE, sabse fast ── */
$GROQ_KEYS = [
    'gsk_apni-key-yahan',
    // 'gsk_apni-key-yahan-key-yahan',
    // 'gsk_apni-key-yahan-key-yahan',
];

/* ── GEMINI (aistudio.google.com) — FREE 1500/day/key ── */
$GEMINI_KEYS = [
    'apni-gemini-key-yahan',
    // 'AIza-nayi-key-yahan',
];

/* ── OPENROUTER (openrouter.ai/keys) — FREE 50/day/key ── */
$OPENROUTER_KEYS = [
    'sk-or-apni-key-yahan',
    // 'sk-or-apni-key-yahanusri-key',
];

/* ── CEREBRAS (cloud.cerebras.ai) — FREE ── */
$CEREBRAS_KEYS = [
    // 'csk-key-yahan',
];

/* ── MISTRAL (console.mistral.ai) — FREE tier ── */
$MISTRAL_KEYS = [
    // 'key-yahan',
];

/* ── DEEPSEEK direct (platform.deepseek.com) — PAID, sabse sasta ── */
$DEEPSEEK_KEYS = [
    // 'sk-key-yahan',
];

/* ── XAI GROK (console.x.ai) — PAID only ── */
$XAI_KEYS = [
    // 'xai-key-yahan',
];

/* ═══════════ NEECHE MAT CHHEDO — auto chain builder ═══════════ */

function lp_clean(array $keys): array {
    return array_values(array_filter($keys, function ($k) {
        $k = trim((string)$k);
        return $k !== '' && stripos($k, 'yahan') === false && stripos($k, 'PASTE') === false;
    }));
}
function lp_rotate(array $keys): array {
    $n = count($keys);
    if ($n < 2) return $keys;
    $i = ((int)(time() / 60)) % $n;   // har minute agli key aage
    return array_merge(array_slice($keys, $i), array_slice($keys, 0, $i));
}

$GROQ_KEYS       = lp_rotate(lp_clean($GROQ_KEYS));
$GEMINI_KEYS     = lp_rotate(lp_clean($GEMINI_KEYS));
$OPENROUTER_KEYS = lp_rotate(lp_clean($OPENROUTER_KEYS));
$CEREBRAS_KEYS   = lp_rotate(lp_clean($CEREBRAS_KEYS));
$MISTRAL_KEYS    = lp_rotate(lp_clean($MISTRAL_KEYS));
$DEEPSEEK_KEYS   = lp_rotate(lp_clean($DEEPSEEK_KEYS));
$XAI_KEYS        = lp_rotate(lp_clean($XAI_KEYS));

$lp_chain = [];
$add = function (array $keys, string $url, array $models) use (&$lp_chain) {
    foreach ($models as $m) {
        foreach ($keys as $k) {
            $lp_chain[] = ['url' => $url, 'key' => $k, 'model' => $m];
        }
    }
};

/* ── TIER 1: FREE + FAST ── */
$add($GROQ_KEYS,   'https://api.groq.com/openai/v1/chat/completions',
     ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant']);
$add($GEMINI_KEYS, 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
     ['gemini-2.0-flash']);
$add($CEREBRAS_KEYS, 'https://api.cerebras.ai/v1/chat/completions',
     ['llama-3.3-70b']);

/* ── TIER 2: FREE BACKUP ── */
$add($MISTRAL_KEYS, 'https://api.mistral.ai/v1/chat/completions',
     ['mistral-small-latest']);
$add($OPENROUTER_KEYS, 'https://openrouter.ai/api/v1/chat/completions',
     ['deepseek/deepseek-chat-v3-0324:free',
      'meta-llama/llama-3.3-70b-instruct:free',
      'qwen/qwen-2.5-72b-instruct:free']);

/* ── TIER 3: PAID LAST RESORT ── */
$add($DEEPSEEK_KEYS, 'https://api.deepseek.com/chat/completions',
     ['deepseek-chat']);
$add($OPENROUTER_KEYS, 'https://openrouter.ai/api/v1/chat/completions',
     ['openai/gpt-4o-mini']);
$add($XAI_KEYS, 'https://api.x.ai/v1/chat/completions',
     ['grok-3-mini']);

if (!defined('PROVIDERS')) define('PROVIDERS', $lp_chain);
if (!defined('OR_MODEL'))  define('OR_MODEL', 'meta-llama/llama-3.3-70b-instruct:free');
